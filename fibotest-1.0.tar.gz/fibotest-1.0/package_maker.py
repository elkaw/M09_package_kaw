#from distutils.core import setup
# the setup.py script is below

from setuptools import setup
setup(name='fibotest',
   version='1.0',
   description='An example package for distutils',
   author='ELK',
   author_email='elk@mitre.net',
   url='https://www.mitre.net',
   py_modules=['fibo', 'test'],
 )
